import React, { useState } from 'react';
import {
  Trophy,
  BarChart3,
  BookOpen,
  User,
  Shield,
  PenTool,
  RefreshCw,
  Pause,
  Play,
  ChevronDown,
  LogOut,
  LogIn,
  UserPlus,
} from 'lucide-react';
import { UserAccount } from '../types/edulms';

interface NavbarProps {
  countdown: number;
  isAutoRefreshPaused: boolean;
  onTogglePause: () => void;
  onRefreshNow: () => void;
  onOpenRulesModal: () => void;
  onOpenAuthModal: () => void;
  activeTab: 'HONORS' | 'ENTRY' | 'PROFILE' | 'ADMIN';
  setActiveTab: (tab: 'HONORS' | 'ENTRY' | 'PROFILE' | 'ADMIN') => void;
  currentUser: UserAccount | null;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  countdown,
  isAutoRefreshPaused,
  onTogglePause,
  onRefreshNow,
  onOpenRulesModal,
  onOpenAuthModal,
  activeTab,
  setActiveTab,
  currentUser,
  onLogout,
}) => {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const handleManualRefresh = () => {
    setIsRefreshing(true);
    onRefreshNow();
    setTimeout(() => setIsRefreshing(false), 500);
  };

  return (
    <header className="bg-white/95 border-b border-slate-200 sticky top-0 z-50 shadow-xs backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo - Prestigious Emblem */}
          <div
            className="flex items-center gap-3 cursor-pointer group select-none shrink-0"
            onClick={() => setActiveTab('HONORS')}
            title="Trang chủ Bảng vinh danh EduLMS"
          >
            <div className="relative">
              {/* Crest background with luxury metallic sheen */}
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 p-0.5 shadow-md shadow-amber-500/25 ring-2 ring-amber-200/60 group-hover:scale-105 transition-transform duration-200">
                <div className="w-full h-full rounded-[14px] bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 flex items-center justify-center relative overflow-hidden">
                  {/* Subtle inner gold glow */}
                  <div className="absolute inset-0 bg-radial from-amber-400/30 via-transparent to-transparent opacity-80" />
                  
                  {/* Intricate Heraldic SVG: Radiant Scripture & Flame */}
                  <svg className="w-6 h-6 text-amber-300 drop-shadow-sm relative z-10" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    {/* Crown / Star radiance */}
                    <path
                      d="M12 2L13.5 5.5L17 6L14.5 8.5L15 12L12 10.2L9 12L9.5 8.5L7 6L10.5 5.5L12 2Z"
                      fill="currentColor"
                      fillOpacity="0.9"
                      strokeWidth="0.5"
                      stroke="#fef08a"
                    />
                    {/* Open Sacred Scripture */}
                    <path
                      d="M4 19.5C5.5 18 8 18 12 19C16 18 18.5 18 20 19.5V8.5C18.5 7 16 7 12 8C8 7 5.5 7 4 8.5V19.5Z"
                      fill="#fef3c7"
                      fillOpacity="0.25"
                      stroke="#fde047"
                      strokeWidth="1.2"
                      strokeLinejoin="round"
                    />
                    {/* Center Spine */}
                    <line x1="12" y1="8" x2="12" y2="19" stroke="#fde047" strokeWidth="1.2" />
                    {/* Gospel Light Lines */}
                    <line x1="6" y1="11.5" x2="10" y2="12" stroke="#fef08a" strokeWidth="0.9" strokeLinecap="round" />
                    <line x1="6" y1="14.5" x2="10" y2="15" stroke="#fef08a" strokeWidth="0.9" strokeLinecap="round" />
                    <line x1="14" y1="12" x2="18" y2="11.5" stroke="#fef08a" strokeWidth="0.9" strokeLinecap="round" />
                    <line x1="14" y1="15" x2="18" y2="14.5" stroke="#fef08a" strokeWidth="0.9" strokeLinecap="round" />
                  </svg>
                </div>
              </div>

              {/* Sparkle badge */}
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-400 rounded-full flex items-center justify-center ring-2 ring-white text-[9px] font-black text-amber-950 shadow-xs">
                ★
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-slate-900 font-cinzel group-hover:text-amber-800 transition-colors">
                  EduLMS
                </span>
                <span className="px-2 py-0.5 text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-md shadow-xs shadow-amber-500/20">
                  Lễ Hội Thi Đua
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">Bảng Vàng Vinh Danh & Mục Tiêu</p>
            </div>
          </div>

          {/* Desktop Navigation Tabs (Spaced out, color-coded, tactile hover states) */}
          <nav className="hidden md:flex items-center gap-2 lg:gap-2.5 text-xs sm:text-sm font-bold">
            {/* Tab 1: Vinh danh */}
            <button
              onClick={() => setActiveTab('HONORS')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all duration-200 cursor-pointer ${
                activeTab === 'HONORS'
                  ? 'text-amber-950 bg-gradient-to-r from-amber-50 via-amber-100/60 to-amber-50 border border-amber-300/80 shadow-xs ring-2 ring-amber-400/20 font-black'
                  : 'text-slate-600 hover:text-amber-900 hover:bg-amber-50/70 border border-transparent'
              }`}
            >
              <div className={`p-1 rounded-lg ${activeTab === 'HONORS' ? 'bg-amber-200/70 text-amber-900' : 'bg-slate-100 text-amber-600'}`}>
                <Trophy className="w-3.5 h-3.5" />
              </div>
              <span>Vinh danh</span>
            </button>

            {/* Tab 2: Nhập kết quả & mục tiêu */}
            <button
              onClick={() => setActiveTab('ENTRY')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all duration-200 cursor-pointer ${
                activeTab === 'ENTRY'
                  ? 'text-emerald-950 bg-gradient-to-r from-emerald-50 via-emerald-100/60 to-emerald-50 border border-emerald-300/80 shadow-xs ring-2 ring-emerald-400/20 font-black'
                  : 'text-slate-600 hover:text-emerald-900 hover:bg-emerald-50/70 border border-transparent'
              }`}
            >
              <div className={`p-1 rounded-lg ${activeTab === 'ENTRY' ? 'bg-emerald-200/70 text-emerald-900' : 'bg-slate-100 text-emerald-600'}`}>
                <PenTool className="w-3.5 h-3.5" />
              </div>
              <span>Nhập kết quả & mục tiêu</span>
            </button>

            {/* Tab 3: Hồ sơ cá nhân (Profile) */}
            <button
              onClick={() => setActiveTab('PROFILE')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all duration-200 cursor-pointer ${
                activeTab === 'PROFILE'
                  ? 'text-blue-950 bg-gradient-to-r from-blue-50 via-blue-100/60 to-blue-50 border border-blue-300/80 shadow-xs ring-2 ring-blue-400/20 font-black'
                  : 'text-slate-600 hover:text-blue-900 hover:bg-blue-50/70 border border-transparent'
              }`}
            >
              <div className={`p-1 rounded-lg ${activeTab === 'PROFILE' ? 'bg-blue-200/70 text-blue-900' : 'bg-slate-100 text-blue-600'}`}>
                <User className="w-3.5 h-3.5" />
              </div>
              <span>Hồ sơ cá nhân</span>
            </button>

            {/* Tab 4: Quản trị (Admin) - Chỉ hiện khi role === 'ADMIN' */}
            {currentUser?.role === 'ADMIN' && (
              <button
                onClick={() => setActiveTab('ADMIN')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all duration-200 cursor-pointer ${
                  activeTab === 'ADMIN'
                    ? 'text-purple-950 bg-gradient-to-r from-purple-50 via-purple-100/60 to-purple-50 border border-purple-300/80 shadow-xs ring-2 ring-purple-400/20 font-black'
                    : 'text-purple-700 hover:text-purple-950 hover:bg-purple-50/70 border border-transparent'
                }`}
              >
                <div className={`p-1 rounded-lg ${activeTab === 'ADMIN' ? 'bg-purple-200/70 text-purple-900' : 'bg-purple-100/80 text-purple-700'}`}>
                  <Shield className="w-3.5 h-3.5" />
                </div>
                <span>Quản trị</span>
              </button>
            )}

            {/* Thể lệ điểm Button (Spaced & Distinctive) */}
            <button
              onClick={onOpenRulesModal}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-amber-800 bg-amber-50/60 hover:bg-amber-100 border border-amber-200/80 hover:border-amber-300 transition-all duration-200 font-bold ml-1 cursor-pointer shadow-2xs hover:scale-102"
              title="Xem chi tiết thể lệ tính điểm & công thức 6 bước"
            >
              <BookOpen className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Thể lệ điểm</span>
            </button>
          </nav>

          {/* Right Action Widgets */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Auto-Refresh Status Pill */}
            <div className="flex items-center bg-slate-100/90 rounded-full pl-2.5 pr-1 py-1 text-xs border border-slate-200">
              <span className="flex items-center gap-1.5 font-medium text-slate-600 mr-1.5">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isAutoRefreshPaused ? 'bg-amber-400' : 'bg-emerald-500 animate-pulse'
                  }`}
                />
                <span className="hidden sm:inline">
                  {isAutoRefreshPaused ? 'Tạm dừng' : 'Làm mới:'}
                </span>
                <span className="font-bold tabular-nums text-slate-800">
                  {isAutoRefreshPaused ? '--' : `${countdown}s`}
                </span>
              </span>

              {/* Pause/Resume button */}
              <button
                onClick={onTogglePause}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-full hover:bg-white transition"
                title={isAutoRefreshPaused ? 'Tiếp tục tự động làm mới' : 'Tạm dừng tự động làm mới'}
              >
                {isAutoRefreshPaused ? (
                  <Play className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Pause className="w-3.5 h-3.5" />
                )}
              </button>

              {/* Manual Refresh button */}
              <button
                onClick={handleManualRefresh}
                className={`p-1 text-slate-500 hover:text-slate-900 rounded-full hover:bg-white transition ${
                  isRefreshing ? 'animate-spin text-blue-600' : ''
                }`}
                title="Làm mới bảng xếp hạng ngay"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* User Profile / Auth Area */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="flex items-center gap-2 pl-1.5 pr-2.5 py-1 rounded-full bg-slate-50 hover:bg-slate-100 border border-slate-200 transition text-left"
                >
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-2xs ${
                    currentUser.role === 'ADMIN' ? 'bg-purple-600' : 'bg-blue-600'
                  }`}>
                    {currentUser.role === 'ADMIN' ? <Shield className="w-3.5 h-3.5" /> : <User className="w-3.5 h-3.5" />}
                  </div>
                  <div className="hidden sm:block text-xs">
                    <div className="font-bold text-slate-900 leading-tight truncate max-w-[110px]">
                      {currentUser.fullName}
                    </div>
                    <div className="text-[10px] text-slate-400 font-medium leading-none">
                      {currentUser.role === 'ADMIN' ? 'Quản trị' : `${currentUser.companyCode} • KV ${currentUser.areaCode}`}
                    </div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {showUserDropdown && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 z-50 animate-in fade-in slide-in-from-top-2">
                    <div className="p-2 border-b border-slate-100">
                      <div className="font-bold text-slate-900 text-xs">{currentUser.fullName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">@{currentUser.username}</div>
                      <div className="mt-1 text-[10px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded w-fit">
                        {currentUser.role === 'ADMIN' ? 'Quyền Quản trị viên' : 'Tài khoản Cá nhân'}
                      </div>
                    </div>

                    <div className="space-y-1 mt-1 text-xs font-semibold">
                      <button
                        onClick={() => {
                          setActiveTab('PROFILE');
                          setShowUserDropdown(false);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-2"
                      >
                        <User className="w-3.5 h-3.5 text-blue-600" />
                        <span>Xem Hồ sơ của tôi</span>
                      </button>

                      <button
                        onClick={() => {
                          setActiveTab('ENTRY');
                          setShowUserDropdown(false);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-2"
                      >
                        <PenTool className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Nhập kết quả & mục tiêu</span>
                      </button>

                      {currentUser.role === 'ADMIN' && (
                        <button
                          onClick={() => {
                            setActiveTab('ADMIN');
                            setShowUserDropdown(false);
                          }}
                          className="w-full text-left px-2.5 py-1.5 rounded-lg text-purple-800 hover:bg-purple-50 flex items-center gap-2"
                        >
                          <Shield className="w-3.5 h-3.5 text-purple-600" />
                          <span>Trang Quản trị hệ thống</span>
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          onOpenAuthModal();
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-2"
                      >
                        <LogIn className="w-3.5 h-3.5 text-slate-500" />
                        <span>Chuyển tài khoản</span>
                      </button>

                      <div className="pt-1 border-t border-slate-100">
                        <button
                          onClick={() => {
                            setShowUserDropdown(false);
                            onLogout();
                          }}
                          className="w-full text-left px-2.5 py-1.5 rounded-lg text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>Đăng xuất</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenAuthModal}
                className="px-3.5 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Đăng nhập</span>
              </button>
            )}

          </div>
        </div>
      </div>

      {/* Mobile Tab Bar */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-200/90 bg-white/95 backdrop-blur-md py-2 px-1 text-[11px] font-bold shadow-lg">
        <button
          onClick={() => setActiveTab('HONORS')}
          className={`flex flex-col items-center py-1 px-2.5 rounded-xl transition cursor-pointer ${
            activeTab === 'HONORS'
              ? 'text-amber-950 bg-amber-50 font-black'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Trophy className={`w-4 h-4 mb-0.5 ${activeTab === 'HONORS' ? 'text-amber-600 scale-110' : 'text-slate-400'}`} />
          <span>Vinh danh</span>
        </button>

        <button
          onClick={() => setActiveTab('ENTRY')}
          className={`flex flex-col items-center py-1 px-2.5 rounded-xl transition cursor-pointer ${
            activeTab === 'ENTRY'
              ? 'text-emerald-950 bg-emerald-50 font-black'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <PenTool className={`w-4 h-4 mb-0.5 ${activeTab === 'ENTRY' ? 'text-emerald-600 scale-110' : 'text-slate-400'}`} />
          <span>Nhập điểm</span>
        </button>

        <button
          onClick={() => setActiveTab('PROFILE')}
          className={`flex flex-col items-center py-1 px-2.5 rounded-xl transition cursor-pointer ${
            activeTab === 'PROFILE'
              ? 'text-blue-950 bg-blue-50 font-black'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <User className={`w-4 h-4 mb-0.5 ${activeTab === 'PROFILE' ? 'text-blue-600 scale-110' : 'text-slate-400'}`} />
          <span>Hồ sơ</span>
        </button>

        {currentUser?.role === 'ADMIN' && (
          <button
            onClick={() => setActiveTab('ADMIN')}
            className={`flex flex-col items-center py-1 px-2.5 rounded-xl transition cursor-pointer ${
              activeTab === 'ADMIN'
                ? 'text-purple-950 bg-purple-50 font-black'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Shield className={`w-4 h-4 mb-0.5 ${activeTab === 'ADMIN' ? 'text-purple-600 scale-110' : 'text-slate-400'}`} />
            <span>Admin</span>
          </button>
        )}

        <button
          onClick={onOpenRulesModal}
          className="flex flex-col items-center py-1 px-2.5 rounded-xl text-amber-800 hover:bg-amber-50/70 transition cursor-pointer"
        >
          <BookOpen className="w-4 h-4 mb-0.5 text-amber-600" />
          <span>Thể lệ</span>
        </button>
      </div>
    </header>
  );
};
